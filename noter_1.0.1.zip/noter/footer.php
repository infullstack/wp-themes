		<footer id="footer">
<section class="links_adlink">
<?php wp_nav_menu(array('theme_location' => 'header_nav', 'echo' => true)); ?>
</section>
<div class="copyright"><a target="_blank" href="http://siinger.com">Theme by Singer, </a><a target="_blank" href="http://www.wordpress.cn">Proudly published with Wordpress</a></div>

</footer>
		
		</div>
	</div>
</div>
<div class="clearer"></div>

<script type='text/javascript' src="//cdn.bootcss.com/jquery/3.0.0-beta1/jquery.min.js"></script>
<?php wp_footer();?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/prettify.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/functions.js?9"></script>
</body>
</html>